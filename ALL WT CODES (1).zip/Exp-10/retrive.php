<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>

    </style>
</head>
<body>
    <?php
    // if (isset($_GET["id"], $_GET["name"])) {
    //     echo $_GET["id"];
    //     echo "</br>";
    //     echo $_GET['name']; 
    // }
    $id = isset($_POST['id']);
    $name = isset($_POST['name']);
    $mail = isset($_POST['mail']);

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mydb";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection error " . $conn->connect_error);
    }
    echo "Connection Successful !!!"."</br></br>";

    $result = $conn->query("SELECT * FROM student");
    echo "<table class='table table-hover container'>
    <tr class='table-dark'>
    <th>ID</th>
    <th>NAME</th>
    <th>EMAIL</th>
    </tr>";
    while($row = mysqli_fetch_array($result))
    {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    echo "</tr>";
    }
    echo "</table>";
      $conn->close();
    ?>
</body>
</html>