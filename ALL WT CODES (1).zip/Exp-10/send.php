<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <?php
        $id = ($_POST['id']);
        $name = ($_POST['name']);
        $mail = ($_POST['mail']);
        // echo $id. $name. $mail;

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "mydb";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection error " . $conn->connect_error);
            }
            echo("Connection Successful !!!");

            $sql = "INSERT INTO student VALUES('$id','$name','$mail')";
            
            if($conn->query($sql)===TRUE)
            {
                echo("Data Inserted !!!");
            }
            else{
                echo "Error - ". $conn->connect_error;
            }
            $conn->close();
    ?>
</body>
</html>